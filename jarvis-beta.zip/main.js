document.addEventListener('DOMContentLoaded', () => {
    const statusText = document.getElementById('status-text');
    const transcriptText = document.getElementById('transcript');
    
    // Check for browser support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        statusText.innerText = "Error: Browser does not support Speech Recognition.";
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'th-TH';
    recognition.continuous = true;
    recognition.interimResults = false;

    recognition.onstart = () => {
        statusText.innerText = "Listening for ghosts...";
        console.log("Voice recognition started.");
    };

    recognition.onresult = (event) => {
        const lastIndex = event.results.length - 1;
        const transcript = event.results[lastIndex][0].transcript.trim().toLowerCase();
        
        console.log("Heard:", transcript);
        transcriptText.innerText = `"${transcript}"`;
        transcriptText.classList.add('visible');
        setTimeout(() => transcriptText.classList.remove('visible'), 2000);

        processCommand(transcript);
    };

    recognition.onerror = (event) => {
        console.error("Speech recognition error", event.error);
        if (event.error === 'not-allowed') {
            statusText.innerText = "Error: Microphone permission denied.";
        } else {
            // Automatically restart on some errors if desired
            statusText.innerText = "Lost connection to the void. Retrying...";
        }
    };

    recognition.onend = () => {
        // Auto-restart to keep listening
        recognition.start();
    };

    // Start listening
    recognition.start();
});

function processCommand(transcript) {
    if (transcript.includes('หิวข้าว')) {
        triggerHungryPrank();
    } else if (transcript.includes('คอมช้า')) {
        triggerSlowComputerPrank();
    } else if (transcript.includes('น่าเบื่อ')) {
        triggerBoringPrank();
    }
}

// Prank Actions

function triggerHungryPrank() {
    console.log("Triggering: Hungry");
    // Open a spooky recipe or gross food site. 
    // Using a search query for "creepy pasta recipes" or a specific image for safety.
    // Let's open a new window with a spooky image search.
    const url = "https://www.google.com/search?q=scary+food+recipes&tbm=isch";
    window.open(url, '_blank');
}

function triggerSlowComputerPrank() {
    console.log("Triggering: Slow Computer");
    const fakeCursor = document.getElementById('fake-cursor');
    fakeCursor.classList.remove('hidden');
    
    // Position it initially
    let x = window.innerWidth / 2;
    let y = window.innerHeight / 2;
    
    // Drift towards top left (refresh button area usually)
    const drift = setInterval(() => {
        x -= (Math.random() * 2 + 0.5); // Slow drift left
        y -= (Math.random() * 2 + 0.5); // Slow drift up
        
        // Add some jitter
        const jitterX = (Math.random() - 0.5) * 10;
        const jitterY = (Math.random() - 0.5) * 10;

        fakeCursor.style.left = (x + jitterX) + 'px';
        fakeCursor.style.top = (y + jitterY) + 'px';

        if (x < 0 || y < 0) {
            clearInterval(drift);
            fakeCursor.classList.add('hidden');
        }
    }, 50);

    // Stop after 10 seconds
    setTimeout(() => {
        clearInterval(drift);
        fakeCursor.classList.add('hidden');
    }, 10000);
}

function triggerBoringPrank() {
    console.log("Triggering: Boring (Whispers)");
    
    // Try to play audio file
    const audio = document.getElementById('whisper-audio');
    if (audio) {
        audio.volume = 0.2; // Low volume
        audio.play().catch(e => {
            console.log("Audio play failed (likely autoplay policy):", e);
            // Fallback: Use TTS to whisper
            speakWhisper("I see you...");
        });
    } else {
        speakWhisper("I see you...");
    }
}

function speakWhisper(text) {
    const synth = window.speechSynthesis;
    const utter = new SpeechSynthesisUtterance(text);
    utter.volume = 0.3;
    utter.rate = 0.6; // Slow
    utter.pitch = 0.1; // Deep/Low pitch
    synth.speak(utter);
}
